package com.an;

import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.metadata.Sheet;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.an.com.an.factory.EasyExcelFactory;
import com.an.com.an.handler.ExcelListener;
import com.an.pojo.LoanInfo;
import org.junit.Test;

import java.io.*;

public class util {

    @Test
    public void testExcel2003WithReflectModel() {
        String inputFileName = "/Users/Annan/Desktop/test.xlsx";
        String outputFileName = "/Users/Annan/Desktop/test_out.xlsx";
        InputStream inputStream;
        try {
             //inputStream = new FileInputStream(inputFileName);
             inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("test.xlsx" );
            ExcelListener<LoanInfo> listener = new ExcelListener<>();
            Sheet sheet = new Sheet(1, 4,LoanInfo.class);
            EasyExcelFactory.readBySax(inputStream,sheet , listener);

            OutputStream out = new FileOutputStream(outputFileName);
            try {

                //写第一个sheet, sheet1  数据全是List<String> 无模型映射关系
                Sheet sheet1 = new Sheet(2, 3, LoanInfo.class, "第yi个sheet", null);
                ExcelWriter writer = EasyExcelFactory.getWriter(out,ExcelTypeEnum.XLSX,true);
                writer.write(listener.getDatas(),sheet1);

                writer.finish();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();

        }

    }
}
