package com.an.util;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.metadata.BaseRowModel;
import com.alibaba.excel.metadata.Sheet;
import com.alibaba.excel.support.ExcelTypeEnum;
import com.an.com.an.factory.EasyExcelFactory;
import com.an.com.an.handler.ExcelListener;
import com.an.pojo.LoanInfo;
import com.an.pojo.SampleDTO;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.ss.formula.functions.T;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.util.CellAddress;
import org.apache.poi.util.SAXHelper;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.model.StylesTable;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import javax.xml.parsers.ParserConfigurationException;

public class ExcelUtil {

    public List<T> extractDataToList(InputStream inputStream, Class<? extends BaseRowModel> clazz, int sheetNo, int headLineMun){
        ExcelListener<T> listener = new ExcelListener<>();
        Sheet sheet = new Sheet(sheetNo, headLineMun, clazz);
        EasyExcelFactory.readBySax(inputStream,sheet , listener);

        return listener.getDatas();
    }

    public void writeFileOut() throws IOException {
        File file = File.createTempFile("tmp", ".xlsx");
        OutputStream outputStream = new FileOutputStream(file);
        FileUtils.readFileToByteArray(file);
       // response.getOutputStream().write(FileUtils.readFileToByteArray(file));
    }


    public void testExcel2003WithReflectModel() {
        String inputFileName = "/Users/Annan/Desktop/test.xlsx";
        String outputFileName = "/Users/Annan/Desktop/test_out.xlsx";
        InputStream inputStream;
        try {
            //inputStream = new FileInputStream(inputFileName);
            inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("test.xlsx" );
            ExcelListener<LoanInfo> listener = new ExcelListener<>();
            Sheet sheet = new Sheet(1, 4,LoanInfo.class);
            EasyExcelFactory.readBySax(inputStream,sheet , listener);

            OutputStream out = new FileOutputStream(outputFileName);
            try {

                //写第一个sheet, sheet1  数据全是List<String> 无模型映射关系
                Sheet sheet1 = new Sheet(2, 3, LoanInfo.class, "第yi个sheet", null);
                ExcelWriter writer = EasyExcelFactory.getWriter(out, ExcelTypeEnum.XLSX,true);
                writer.write(listener.getDatas(),sheet1);

                writer.finish();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();

        }

    }

}
